export default function getTrafficColor(trafficPercentage: number): string {
  const min = 0;
  const max = 100;

  // Clamp traffic percentage between 0 and 100
  const clampedPercentage = Math.min(Math.max(trafficPercentage, min), max);

  let color: string;
  if (clampedPercentage >= 90) {
    color = '#00ff00'; // Bright green
  } else if (clampedPercentage >= 80) {
    color = '#66ff66'; // Light green
  } else if (clampedPercentage >= 70) {
    color = '#ffff66'; // Yellow
  } else if (clampedPercentage >= 60) {
    color = '#ffcc00'; // Gold
  } else if (clampedPercentage >= 50) {
    color = '#ff6600'; // Orange
  } else {
    color = '#ff0000'; // Red
  }

  return color;
}