import "./css/LogosContainer.css"
import wimmaLabLogo from "/images/jamk_logo.png";
import iotitudeLogo from "/images/Codecrafters.png";
import { Tooltip } from 'react-tooltip'

// this component returns loading screen for tukko

export const LogosContainer = () => {
return (
    <div className="logosContainer">
        <a 
        href="https://www.jamk.fi/en" 
        target="_blank"
        data-tooltip-id="logo-tooltip"
        data-tooltip-content="Visit JAMK"
        data-tooltip-place="top"
        >
          <img
            className="wimmaLabLogo"
            src={wimmaLabLogo}
            alt="JAMK Logo"
          />
        </a>
        <a
          href="https://site-it-ff-2024-t10-48f97c6356118fb8b1dfe5f941b525bed147af0ce2e.pages.labranet.jamk.fi/"
          target="_blank"
          data-tooltip-id="logo-tooltip"
          data-tooltip-content="Visit CodeCrafters webpage"
          data-tooltip-place="top"
        >
          <img
            className="iotitudeLogo"
            src={iotitudeLogo}
            alt="CodeCrafters Logo"
          />
        </a>
        <Tooltip id="logo-tooltip"/>
      </div>
)
};

export default LogosContainer;
