import React, { useState } from "react";
import axios from "axios";
import "./css/login.css";

interface LoginProps {
  onLogin: () => void;
  onRegisterClick: () => void;
}

interface LoginFormData {
  username: string;
  password: string;
}

const Login: React.FC<LoginProps> = ({ onLogin, onRegisterClick }) => {
  const [formData, setFormData] = useState<LoginFormData>({
    username: "",
    password: ""
  });
  const [error, setError] = useState<string>("");

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      const response = await axios.post(`${window.API_URL}/auth/login`, formData);
      const token = response.data.token;
      localStorage.setItem("token", token);
      onLogin();
    } catch (error) {
      console.error("Login failed:", error);
      setError("Invalid credentials Enter Again"); // Set error message for incorrect login
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <h2>Login</h2>
        {error && <p className="error-message">{error}</p>} {/* Display error message */}
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="User email"
            value={formData.username}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <button type="submit">Login</button>
          <button type="button" onClick={onRegisterClick}>Register</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
