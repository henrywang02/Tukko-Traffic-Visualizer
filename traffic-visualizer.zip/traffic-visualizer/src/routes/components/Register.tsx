import React, { useState } from "react";
import axios from "axios"; // Import axios for making HTTP requests
import "./css/register.css";

interface RegisterProps {
  onRegister: () => void;
  onGoToLogin: () => void; // Add prop for handling navigation to login
}

interface RegisterFormData {
  username: string;
  email: string;
  password: string;
}

const Register: React.FC<RegisterProps> = ({ onRegister, onGoToLogin }) => {
  const [formData, setFormData] = useState<RegisterFormData>({
    username: "",
    email: "",
    password: ""
  });
  const [error, setError] = useState<string>(""); // State for error message

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      // Make HTTP request to backend register endpoint
      await axios.post(`${window.API_URL}/auth/register`, formData);
      // Trigger register action in parent component
      onRegister();
    } catch (error) {
      console.error("Registration failed:", error);
      setError("User already exists"); // Set error message for existing user
    }
  };

  const handleGoToLogin = () => {
    onGoToLogin(); // Call the function passed as prop to navigate to login form
  };

  return (
    <div className="register-container">
      <div className="register-form">
        <h1>Register</h1>
        {error && <p className="error-message">{error}</p>} {/* Display error message */}
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={formData.username}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <button type="submit">Register</button>
        </form>
        <button type="button" onClick={handleGoToLogin}>Back to Login</button> {/* Add button for navigating to login */}
      </div>
    </div>
  );
};

export default Register;
