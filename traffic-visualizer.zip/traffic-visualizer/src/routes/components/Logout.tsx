// logout.tsx

import React from "react";
import axios, { AxiosError } from "axios";
import "./css/logout.css";


interface LogoutProps {
  onLogout: () => void; // Callback function to handle logout in parent component
}

const Logout: React.FC<LogoutProps> = ({ onLogout }) => {
  const handleLogout = async () => {
    try {
      // Make HTTP request to backend logout endpoint
      let res = await axios.post(`${window.API_URL}/auth/logout`);

      // Clear token from local storage or cookie
      localStorage.removeItem("token");
      // Trigger logout action in parent component
    } catch (e) {
      let error = e as AxiosError
      if (!(error.status==400 && (error?.response?.data as {identifier: string})?.identifier == "absurd_request")){
        throw error
      }
    }
    onLogout()
  };

  return (
    <button className="logout-button" onClick={handleLogout}>Logout</button>
  );
};

export default Logout;
