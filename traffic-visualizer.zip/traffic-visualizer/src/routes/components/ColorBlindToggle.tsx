import { useState, useEffect } from "react";
import { useMap } from "react-leaflet";
import Toggle from "react-toggle";
import { useMediaQuery } from "react-responsive";
import "react-toggle/style.css";
import "./css/ColorBlindToggle.css";

// Imports icon assets
import asd1 from "../../assets/toggleIcons/eye-regular.svg";
import asd2 from "../../assets/toggleIcons/eye-solid.svg";

export const ColorBlindToggle = () => {
  const [isColorBlind, setIsColorBlind] = useState(false);

  // Adds/removes css class "dark" from body element when isColorBlind updates
  useEffect(() => {
    if (isColorBlind) {
      document.body.classList.add("blind");
    } else {
      document.body.classList.remove("blind");
    }
  }, [isColorBlind]);

  // Checks users system color scheme preference
  useMediaQuery(
    {
      query: "(prefers-color-scheme: blind)",
    },
    undefined,
    (isSystemBlind) => setIsColorBlind(isSystemBlind)
  );

  const map = useMap()

  return (
    <div
        id="toggleContainer"
        onMouseEnter={() => map.dragging.disable() && map.scrollWheelZoom.disable()}
        onMouseLeave={() => map.dragging.enable() && map.scrollWheelZoom.enable()}
    >
      <Toggle
        className="ToggleBlind"
        // Updates "isColorBlind" state on click
        checked={isColorBlind}
        onChange={({ target }) => setIsColorBlind(target.checked)}
        aria-label="Color blind mode toggle"
        icons={{
          checked: (
            <img src={asd1} alt="Sun Icon" className="toggle-icon" />
          ),
          unchecked: (
            <img src={asd2} alt="Moon Icon" className="toggle-icon" />
          ),
        }}
      />
    </div>
  );
};