import  { Fragment, Suspense, useContext, useRef, useState } from "react";
import Login from "./components/Login";
import Register  from "./components/Register";
import { MapContainer, TileLayer } from "react-leaflet";
import { Map } from "leaflet";
import "./leaflet.css";
import "./root.css";
import { StationContext, Context } from "../context/StationContext";
import Geoman from "./components/Geoman";
import { ColorBlindToggle } from "./components/ColorBlindToggle";
import { DarkModeToggle } from "./components/DarkModeToggle";
import { MapLayers } from "./components/MapLayers";
import { FeedbackForm } from "./components/FeedbackForm";
import { LogosContainer } from "./components/LogosContainer";
import { LangToggle } from "./components/LangSelect";
import ModalData from "./components/ModalData";
import Logout from "./components/Logout";
import { loadLanguages } from "i18next";

function MapPlaceholder(): JSX.Element {
  return (
    <p>
      Tukko - Traffic Visualizer
      <noscript>You need to enable JavaScript to see this map.</noscript>
    </p>
  );
}

export default function Root(): JSX.Element {
  const { station } = useContext(StationContext) as Context;
  const mapRef = useRef<Map | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setIsRegistering(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("token")
    setIsLoggedIn(false);
  };

  const handleToggleRegistration = () => {
    setIsRegistering((prevState) => !prevState);
  };

  const handleGoToLogin = () => {
    setIsRegistering(false);
  };

  return (
    <Fragment>
      <h1 id="overlay-title" className="overlay-title">
        Tukko
      </h1>
      <h2 className="overlay2-title">Traffic Visualizer</h2>
      <LogosContainer />

      {!isLoggedIn && !isRegistering && (
        <Login
          onLogin={handleLogin}
          onRegisterClick={handleToggleRegistration} // Pass handleToggleRegistration function
        />
      )}
      {!isLoggedIn && isRegistering && <Register onRegister={handleLogin} onGoToLogin={handleGoToLogin} />}
      {isLoggedIn && (
        <MapContainer
          center={[60.2, 24.9]}
          maxBoundsViscosity={0.9}
          zoomDelta={1}
          zoom={12}
          minZoom={7}
          maxZoom={17}
          placeholder={<MapPlaceholder />}
          doubleClickZoom={false}
          ref={mapRef}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors | <a target="_blank" href="https://wimma-lab-2023.pages.labranet.jamk.fi/iotitude/core-traffic-visualizer/80-Documents-and-reporting/gdpr-statement/">GDPR</a> | <a target="_blank" href="https://wimma-lab-2023.pages.labranet.jamk.fi/iotitude/core-traffic-visualizer/80-Documents-and-reporting/user-guide/">User Guide for Tukko</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Geoman />
          <ColorBlindToggle />
          <DarkModeToggle />
          <Suspense>
            <FeedbackForm />
          </Suspense>
          <MapLayers />
          <div className="langContainer">
            <LangToggle />
          </div>
          <Logout onLogout={handleLogout} />
        </MapContainer>
        
      )}
      <Suspense>
        {station && <ModalData targetID={station.id.toString()} />}
      </Suspense>
    </Fragment>
  );
}
